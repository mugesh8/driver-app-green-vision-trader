import {
  User,
  Phone,
  Mail,
  MapPin,
  Building2,
  Globe,
  Hash,
  CreditCard,
  Calendar,
  FileText,
  Car,
  Truck,
  Scale,
  Star,
  Pencil,
} from 'lucide-react';
import { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { putFormData, get } from '../api/client';

const InfoField = ({ icon: Icon, label, value, name, editable, onChange }) => (
  <div className="mb-4">
    <label className="text-[#A0A0A0] text-xs block mb-1">{label}</label>
    <div className="flex items-center gap-3 py-3 px-4 rounded-xl bg-[#2C2C2C]">
      <Icon className="w-5 h-5 text-gray-500 flex-shrink-0" strokeWidth={2} />
      {editable ? (
        <input
          type="text"
          name={name}
          value={value || ''}
          onChange={onChange}
          className="bg-transparent text-white text-sm flex-1 outline-none"
        />
      ) : (
        <span className="text-white text-sm">{value || '-'}</span>
      )}
    </div>
  </div>
);

export default function Profile() {
  const { user, token } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loading, setLoading] = useState(true);
  const [formData, setFormData] = useState({
    driver_name: '',
    phone_number: '',
    email: '',
    address: '',
    city: '',
    state: '',
    pin_code: '',
    license_number: '',
    license_expiry_date: '',
    vehicle_ownership: '',
    available_vehicle: '',
    vehicle_number: '',
    capacity: '',
    vehicle_condition: '',
    insurance_number: '',
    insurance_expiry_date: '',
    pollution_certificate: '',
    pollution_certificate_expiry_date: '',
    ka_permit: '',
    ka_permit_expiry_date: '',
    account_holder_name: '',
    bank_name: '',
    branch_name: '',
    account_number: '',
    IFSC_code: '',
    delivery_type: '',
    status: '',
  });

  useEffect(() => {
    const fetchDriverData = async () => {
      try {
        setLoading(true);
        const driverId = user?.did ?? user?.data?.did ?? user?.id ?? user?.driver_id ?? user?.driverId ?? user?._id;
        
        const response = await get(`/driver/profile/${driverId}`, token);
        const driver = response.data || response;
        
        setFormData({
          driver_name: driver.driver_name || driver.name || '',
          phone_number: driver.phone_number || driver.phone || '',
          email: driver.email || '',
          address: driver.address || '',
          city: driver.city || '',
          state: driver.state || '',
          pin_code: driver.pin_code || driver.pincode || '',
          license_number: driver.license_number || driver.license || '',
          license_expiry_date: driver.license_expiry_date || '',
          vehicle_ownership: driver.vehicle_ownership || driver.vehicle_type || '',
          available_vehicle: driver.available_vehicle || driver.vehicleType || '',
          vehicle_number: driver.vehicle_number || driver.vehicleNumber || '',
          capacity: driver.capacity || '',
          vehicle_condition: driver.vehicle_condition || driver.vehicleCondition || '',
          insurance_number: driver.insurance_number || '',
          insurance_expiry_date: driver.insurance_expiry_date || '',
          pollution_certificate: driver.pollution_certificate || '',
          pollution_certificate_expiry_date: driver.pollution_certificate_expiry_date || '',
          ka_permit: driver.ka_permit || '',
          ka_permit_expiry_date: driver.ka_permit_expiry_date || '',
          account_holder_name: driver.account_holder_name || '',
          bank_name: driver.bank_name || '',
          branch_name: driver.branch_name || '',
          account_number: driver.account_number || '',
          IFSC_code: driver.IFSC_code || driver.ifsc_code || '',
          delivery_type: driver.delivery_type || driver.deliveryType || '',
          status: driver.status || '',
        });
      } catch (error) {
        console.error('Failed to load driver data:', error);
      } finally {
        setLoading(false);
      }
    };

    if (user) {
      fetchDriverData();
    } else {
      setLoading(false);
    }
  }, [user, token]);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSave = async () => {
    try {
      setSaving(true);
      const driverId = user?.did ?? user?.data?.did ?? user?.id ?? user?.driver_id ?? user?.driverId ?? user?._id;
      
      const formDataToSend = new FormData();
      Object.keys(formData).forEach(key => {
        if (formData[key]) {
          formDataToSend.append(key, formData[key]);
        }
      });
      
      await putFormData(`/driver/${driverId}`, formDataToSend, token);
      
      setIsEditing(false);
      alert('Profile updated successfully');
    } catch (error) {
      console.error('Failed to update profile:', error);
      alert('Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="px-4 py-4 pb-24 flex justify-center items-center h-screen">
        <div className="text-white">Loading...</div>
      </div>
    );
  }

  return (
    <div className="px-4 py-4 pb-24 space-y-6">
      <div className="rounded-2xl bg-[#10B981] p-4 relative">
        <div className="flex gap-4">
          <div className="w-16 h-16 rounded-full bg-white flex items-center justify-center flex-shrink-0">
            <User className="w-8 h-8 text-[#10B981]" strokeWidth={2} />
          </div>
          <div className="flex-1">
            <h2 className="text-white font-bold text-lg">{formData.driver_name}</h2>
            <p className="text-white/80 text-sm">Driver ID</p>
            <p className="text-white text-sm">{user?.did ?? user?.data?.did ?? user?.id}</p>
            <div className="flex items-center gap-2 mt-2">
              <span className="px-2 py-1 rounded-lg bg-[#F59E0B] text-white text-xs">
                {formData.status || 'Available'}
              </span>
            </div>
          </div>
          {!isEditing ? (
            <button
              type="button"
              onClick={() => setIsEditing(true)}
              className="w-10 h-10 rounded-full bg-white flex items-center justify-center absolute top-4 right-4"
            >
              <Pencil className="w-5 h-5 text-gray-700" strokeWidth={2} />
            </button>
          ) : (
            <div className="absolute top-4 right-4 flex gap-2">
              <button
                type="button"
                onClick={() => setIsEditing(false)}
                className="px-3 py-1 rounded-lg bg-gray-500 text-white text-sm"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleSave}
                disabled={saving}
                className="px-3 py-1 rounded-lg bg-white text-gray-700 text-sm disabled:opacity-50"
              >
                {saving ? 'Saving...' : 'Save'}
              </button>
            </div>
          )}
        </div>
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">Personal Information</h3>
        <InfoField icon={User} label="Name" value={formData.driver_name} name="driver_name" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Phone} label="Phone Number" value={formData.phone_number} name="phone_number" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Mail} label="Email" value={formData.email} name="email" editable={isEditing} onChange={handleChange} />
        <InfoField icon={MapPin} label="Address" value={formData.address} name="address" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Building2} label="City" value={formData.city} name="city" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Globe} label="State" value={formData.state} name="state" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Hash} label="Pin Code" value={formData.pin_code} name="pin_code" editable={isEditing} onChange={handleChange} />
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">License Information</h3>
        <InfoField icon={CreditCard} label="License Number" value={formData.license_number} name="license_number" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Calendar} label="License Expiry Date" value={formData.license_expiry_date} name="license_expiry_date" editable={isEditing} onChange={handleChange} />
        <InfoField icon={FileText} label="License Image" value="" editable={false} />
        <InfoField icon={FileText} label="ID Proof" value="" editable={false} />
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">Vehicle Information</h3>
        <InfoField icon={Car} label="Vehicle Type" value={formData.vehicle_ownership} name="vehicle_ownership" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Truck} label="Available Vehicle" value={formData.available_vehicle} name="available_vehicle" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Car} label="Vehicle Number" value={formData.vehicle_number} name="vehicle_number" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Scale} label="Capacity (KG)" value={formData.capacity} name="capacity" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Star} label="Vehicle Condition" value={formData.vehicle_condition} name="vehicle_condition" editable={isEditing} onChange={handleChange} />
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">Insurance Information</h3>
        <InfoField icon={FileText} label="Insurance Number" value={formData.insurance_number} name="insurance_number" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Calendar} label="Insurance Expiry Date" value={formData.insurance_expiry_date} name="insurance_expiry_date" editable={isEditing} onChange={handleChange} />
        <InfoField icon={FileText} label="Insurance Document" value="" editable={false} />
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">Permits & Certificates</h3>
        <InfoField icon={FileText} label="Pollution Certificate" value={formData.pollution_certificate} name="pollution_certificate" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Calendar} label="Pollution Expiry Date" value={formData.pollution_certificate_expiry_date} name="pollution_certificate_expiry_date" editable={isEditing} onChange={handleChange} />
        <InfoField icon={FileText} label="Pollution Certificate Document" value="" editable={false} />
        <InfoField icon={FileText} label="KA Permit" value={formData.ka_permit} name="ka_permit" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Calendar} label="KA Permit Expiry Date" value={formData.ka_permit_expiry_date} name="ka_permit_expiry_date" editable={isEditing} onChange={handleChange} />
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">Bank Account Details</h3>
        <InfoField icon={User} label="Account Holder Name" value={formData.account_holder_name} name="account_holder_name" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Building2} label="Bank Name" value={formData.bank_name} name="bank_name" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Building2} label="Branch Name" value={formData.branch_name} name="branch_name" editable={isEditing} onChange={handleChange} />
        <InfoField icon={CreditCard} label="Account Number" value={formData.account_number} name="account_number" editable={isEditing} onChange={handleChange} />
        <InfoField icon={Hash} label="IFSC Code" value={formData.IFSC_code} name="IFSC_code" editable={isEditing} onChange={handleChange} />
      </div>

      <div>
        <h3 className="text-white font-bold text-base mb-4">Delivery Type</h3>
        <InfoField icon={Truck} label="Delivery Type" value={formData.delivery_type} name="delivery_type" editable={false} />
      </div>
    </div>
  );
}
